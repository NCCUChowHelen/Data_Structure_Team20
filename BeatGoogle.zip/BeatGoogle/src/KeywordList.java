import java.util.ArrayList;

public class KeywordList
{
	private ArrayList<Keyword> keywords;

	public KeywordList() 
	{
		this.keywords = new ArrayList<Keyword>();
		keywords.add(new Keyword("台灣", 2));
		keywords.add(new Keyword("登山", 3));
		keywords.add(new Keyword("曙光", 1));
		keywords.add(new Keyword("安全", 2));
		keywords.add(new Keyword("日落", 1));
		keywords.add(new Keyword("住宿", 2));
		keywords.add(new Keyword("抽籤", 1));
		keywords.add(new Keyword("入園證", 3));
		keywords.add(new Keyword("賞雪", 4));
		keywords.add(new Keyword("冬季", 4));
		keywords.add(new Keyword("百岳", 4));
		keywords.add(new Keyword("雪景", 5));
		keywords.add(new Keyword("雲海", 1));
		keywords.add(new Keyword("下雪", 4));
		keywords.add(new Keyword("美景", 1));
	}
	
	public void printKeywordList(ArrayList<Keyword> kLst) 
	{
		for(Keyword k: kLst) 
		{
			System.out.println(k.toString1());
		}
	}
	
	public ArrayList<Keyword> getKeywords() 
	{
		return keywords;
	}
}
