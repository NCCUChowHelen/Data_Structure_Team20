package google;

import java.util.ArrayList;

public class Rank {
	private ArrayList<WebTree> webs;
	public Rank(ArrayList<WebTree> webs) {
		this.webs=webs;
	}
	public void quickSort(int leftbound,int rightbound) {
		if(leftbound>=rightbound) return;
		WebTree t=webs.get(rightbound);
		int j=leftbound,k=rightbound-1;
		while(j<k) {
			for(;j<k;j++) {
				if(webs.get(j).score<t.score) {
					for(;k>j;k--) {
						if(webs.get(k).score>=t.score) {
							WebTree tr=webs.get(j);
							webs.set(j, webs.get(k));
							webs.set(k, tr);
							break;
						}
					}
				}
			}
			webs.add(j, webs.get(rightbound));
			webs.remove(rightbound+1);
		}
		quickSort(leftbound,j-1);
		quickSort(j+1,rightbound);
	}
	public  ArrayList<WebTree> getRank(){
		this.quickSort(0,webs.size()-1);
		return webs;
	}
}


