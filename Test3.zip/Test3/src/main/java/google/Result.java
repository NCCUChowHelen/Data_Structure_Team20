package google;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Scanner;

public class Result {
	public String url;
	public String result;
	
	public Result(){
		this.url=url;
		this.result=result;
		}

	
	public String getSearchurl() {
		return this.url;
	}
	public void setSearchUrl(String url) {
		this.url = url;
	}
	public String showResult() throws FileNotFoundException, UnsupportedEncodingException{
		//KeywordList kLst = new KeywordList();
		//File file = new File("Keyword.txt");
		//Scanner sc = new Scanner(file);
		KeywordList kLst = new KeywordList();
		
		/*while(sc.hasNext()){
		    String cmd = sc.next();
		    switch(cmd){
	        	case "add":{
	        		String name = sc.next();
	        		float weight = sc.nextFloat();
	        		Keyword k = new Keyword(name, weight);
	        		kLst.add(k);
	        	}
        	    default:
        	    	System.out.println("InvalidOperation0");       	    	      
		    }
		}
		sc.close();*/
		Keyword k = new Keyword("NCCU", 10.2);
		kLst.add(k);
		try {
			SultWeb test=new SultWeb(url);
			ArrayList<WebTree> webs=test.getTrees();
			Rank rank=new Rank(test.getTrees());
			webs=rank.getRank();
			/*for(int i=0;i<webs.size();i++) {
				webs.get(i).setPostOrderScore(kLst.getList());
				webs.get(i).eularPrintTree();
			}*/
			//String result="";
			result="";
			for(int i=0;i<webs.size();i++) {
				result+=webs.get(i).root.webPage.name;
				result+=" 的url是 :\n";
				result+=webs.get(i).root.webPage.url;
				result+="\n";
			}
			//System.out.println(result);
			return result;
			
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
		return " ";
	}
	
}
