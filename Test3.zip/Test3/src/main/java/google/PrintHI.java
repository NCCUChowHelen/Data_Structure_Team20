package google;

public class PrintHI {
	public String printHi() {
		return "HI";
	}

}
